module.exports = [
"[project]/.next-internal/server/app/api/inventory/adjust/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_inventory_adjust_route_actions_7b7a824f.js.map