module.exports = [
"[project]/.next-internal/server/app/api/reports/top-products/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_reports_top-products_route_actions_b6d0e6a3.js.map