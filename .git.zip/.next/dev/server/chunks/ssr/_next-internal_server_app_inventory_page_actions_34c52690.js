module.exports = [
"[project]/.next-internal/server/app/inventory/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_inventory_page_actions_34c52690.js.map