module.exports = [
"[project]/.next-internal/server/app/inventory-history/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_inventory-history_page_actions_0220a9eb.js.map