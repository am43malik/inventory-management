module.exports = [
"[project]/.next-internal/server/app/sales/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_sales_page_actions_387cd0a2.js.map