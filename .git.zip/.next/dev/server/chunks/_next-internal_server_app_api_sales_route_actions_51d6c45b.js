module.exports = [
"[project]/.next-internal/server/app/api/sales/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_sales_route_actions_51d6c45b.js.map