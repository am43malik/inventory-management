var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/adjust/route.js")
R.c("server/chunks/node_modules_next_edf0bed0._.js")
R.c("server/chunks/node_modules_zod_v4_dead09ad._.js")
R.c("server/chunks/node_modules_c347398c._.js")
R.c("server/chunks/[root-of-the-server]__c997fc8e._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_adjust_route_actions_7b7a824f.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/inventory/adjust/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/inventory/adjust/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
