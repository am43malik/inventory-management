var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/verify/route.js")
R.c("server/chunks/node_modules_789d6ef8._.js")
R.c("server/chunks/[root-of-the-server]__86b33e3b._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_verify_route_actions_bc110aab.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/verify/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/verify/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
