var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/node_modules_next_ee3d79e1._.js")
R.c("server/chunks/node_modules_zod_v4_dead09ad._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/[root-of-the-server]__00cf5cd7._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register_route_actions_3564e727.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/register/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/register/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
