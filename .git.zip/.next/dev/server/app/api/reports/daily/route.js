var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/daily/route.js")
R.c("server/chunks/node_modules_e5d42668._.js")
R.c("server/chunks/[root-of-the-server]__37c027b1._.js")
R.c("server/chunks/_next-internal_server_app_api_reports_daily_route_actions_148c7d58.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/reports/daily/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/reports/daily/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
